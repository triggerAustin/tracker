import { useCallback, useEffect, useState } from 'react'
import type { FormEvent, RefObject } from 'react'
import { api } from './api'
import type { ProjectDetail as Detail } from './types'
import { dueLabel, dueTone, timeAgo } from './format'
import { Bar, Chip, Pane, gitInfo, input, stageInfo } from './ui'

const none = (t: string) => <p className="text-dim">{t}</p>
const more = (n: number, cap: number) => n > cap && <p className="text-dim">+{n - cap} more</p>

export default function ProjectDetail({
  slug,
  goalRef,
}: {
  slug: string
  goalRef: RefObject<HTMLInputElement | null>
}) {
  const [d, setD] = useState<Detail | null>(null)
  const [err, setErr] = useState<string | null>(null)
  const [text, setText] = useState('')

  const load = useCallback(() => {
    api
      .getProject(slug)
      .then((x) => {
        setD(x)
        setErr(null)
      })
      .catch((e: unknown) => setErr(String(e)))
  }, [slug])

  useEffect(() => {
    load()
    const t = setInterval(load, 15000)
    return () => clearInterval(t)
  }, [load])

  async function addGoal(e: FormEvent) {
    e.preventDefault()
    const v = text.trim()
    if (!v) return
    await api.addGoal(slug, v)
    setText('')
    load()
  }

  async function toggle(id: string) {
    await api.toggleGoal(slug, id)
    load()
  }

  if (err) return <p className="p-2 text-bad">couldn’t load project: {err}</p>
  if (!d || d.slug !== slug) return <p className="p-2 text-dim">loading…</p>

  const st = stageInfo[d.stage]
  const g = gitInfo[d.git.state]
  const l = d.leftOff
  const goals = [...d.goals].sort((a, b) => Number(a.done) - Number(b.done))
  const readmeTitle = d.readme.split('\n').find(Boolean)?.replace(/^#+\s*/, '')

  return (
    <div className="h-full overflow-auto p-2">
      <header className="mb-2">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
          <h1 className="text-base font-bold">{d.title}</h1>
          <Chip tone={st.tone}>{d.stage}</Chip>
          <Chip tone={g.tone}>{g.label}</Chip>
          {d.git.branch && <span className="text-cyan">{d.git.branch}</span>}
          <span className="text-dim">
            {d.hoursThisWeek.toFixed(1)}h this week, active {timeAgo(d.lastActive)}
          </span>
        </div>
        <p className="text-dim">{d.goal}</p>
      </header>

      <div className="columns-1 gap-2 md:columns-2 2xl:columns-3">
        <Pane title="left off" tone="cyan">
          {l ? (
            <>
              <p className="font-bold">{l.summary}</p>
              <p className="text-dim">
                last commit: <span className="text-fg">{l.lastCommit}</span>
              </p>
              {l.uncommitted.slice(0, 4).map((f) => (
                <div key={f} className="text-warn">
                  ± {f}
                </div>
              ))}
              {more(l.uncommitted.length, 4)}
            </>
          ) : (
            none('no activity yet. work in the project folder and this fills in.')
          )}
        </Pane>

        <Pane title="next up" tone="info">
          {d.next.length === 0
            ? none('nothing queued. add a checklist to the README.')
            : d.next.slice(0, 4).map((i) => (
                <div key={i.id} className="flex gap-2">
                  <span className={i.status === 'doing' ? 'font-bold text-ok' : 'text-dim'}>
                    {i.status === 'doing' ? '▶' : '-'}
                  </span>
                  <span className="min-w-0 truncate">{i.title}</span>
                  <span className="ml-auto shrink-0 text-dim">{i.source}</span>
                </div>
              ))}
          {more(d.next.length, 4)}
        </Pane>

        <Pane title="goals" tone="violet">
          <form onSubmit={addGoal} className="flex gap-2">
            <span className="text-violet">+</span>
            <input
              ref={goalRef}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="finish login by friday"
              aria-label="New goal"
              className={input}
            />
          </form>
          {goals.length === 0 && none('no goals. type one and press enter.')}
          {goals.slice(0, 5).map((x) => (
            <button
              key={x.id}
              role="checkbox"
              aria-checked={x.done}
              onClick={() => toggle(x.id)}
              className="flex w-full gap-2 text-left hover:bg-panel"
            >
              <span className={x.done ? 'text-ok' : 'text-violet'}>{x.done ? '[x]' : '[ ]'}</span>
              <span className={x.done ? 'text-dim line-through' : ''}>{x.title}</span>
              {!x.done && <span className={`ml-auto shrink-0 ${dueTone(x.due)}`}>{dueLabel(x.due)}</span>}
            </button>
          ))}
          {more(goals.length, 5)}
        </Pane>

        <Pane title="activity" tone="orange">
          {d.activity.length === 0
            ? none('no work recorded yet.')
            : d.activity.slice(0, 4).map((a) => (
                <div key={a.id} className="flex gap-3">
                  <span className="w-12 shrink-0 text-orange">{timeAgo(a.at)}</span>
                  <span>{a.text}</span>
                </div>
              ))}
          {more(d.activity.length, 4)}
        </Pane>

        <Pane title="milestones" tone="pink">
          {d.milestones.length === 0
            ? none('none set.')
            : d.milestones.map((m) => (
                <div key={m.id}>
                  <p>{m.title}</p>
                  <p>
                    <Bar done={m.done} total={m.total} /> <span className={dueTone(m.due)}>{dueLabel(m.due)}</span>
                  </p>
                </div>
              ))}
        </Pane>

        <Pane title="sources">
          {d.sources.length === 0
            ? none('not linked to a folder or repo.')
            : d.sources.map((x) => (
                <div key={x.name} className="flex gap-2">
                  <span className="w-14 shrink-0 text-dim">{x.name}</span>
                  <span className="min-w-0 truncate">{x.detail}</span>
                  <span className="ml-auto shrink-0 text-dim">{x.syncedAt ? timeAgo(x.syncedAt) : 'not synced'}</span>
                </div>
              ))}
        </Pane>

        <Pane title="readme">
          {d.readme ? (
            <details>
              <summary className="cursor-pointer hover:text-cyan">{readmeTitle}</summary>
              <pre className="mt-1 max-h-56 overflow-auto whitespace-pre-wrap text-dim">{d.readme}</pre>
            </details>
          ) : (
            none('no README in the project folder.')
          )}
        </Pane>
      </div>
    </div>
  )
}
