import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { api, isMock } from './api'
import type { NewProject, Project } from './types'
import ProjectList from './ProjectList'
import ProjectDetail from './ProjectDetail'
import NewProjectModal from './NewProjectModal'
import { btn } from './ui'

const filters = ['all', 'attention', 'active', 'new', 'planned', 'paused', 'shipped'] as const
type Filter = (typeof filters)[number]
const attention = (p: Project) => p.stage !== 'planned' && p.git.state !== 'clean'

const Key = ({ k, children }: { k: string; children: string }) => (
  <span>
    <b className="text-fg">{k}</b> {children}
  </span>
)

export default function App() {
  const [projects, setProjects] = useState<Project[]>([])
  const [selected, setSelected] = useState<string | null>(null)
  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState<Filter>('all')
  const [creating, setCreating] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const searchRef = useRef<HTMLInputElement>(null)
  const goalRef = useRef<HTMLInputElement>(null)

  const refresh = useCallback(
    () =>
      api
        .listProjects()
        .then((list) => {
          setProjects(list)
          setError(null)
        })
        .catch((e: unknown) => setError(String(e))),
    [],
  )

  useEffect(() => {
    refresh()
    const t = setInterval(refresh, 15000)
    return () => clearInterval(t)
  }, [refresh])

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase()
    return projects
      .filter((p) => (filter === 'all' ? true : filter === 'attention' ? attention(p) : p.stage === filter))
      .filter((p) => !q || `${p.title} ${p.goal} ${p.tags.join(' ')}`.toLowerCase().includes(q))
      .sort((a, b) => (b.lastActive ?? '').localeCompare(a.lastActive ?? ''))
  }, [projects, query, filter])

  const current = rows.find((p) => p.slug === selected) ?? rows[0] ?? null

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        if (e.key === 'Escape') el.blur()
        return
      }
      if (creating || e.metaKey || e.ctrlKey || e.altKey) return
      const i = rows.findIndex((p) => p.slug === current?.slug)
      if (e.key === 'j' || e.key === 'ArrowDown') {
        e.preventDefault()
        setSelected(rows[Math.min(rows.length - 1, i + 1)]?.slug ?? null)
      } else if (e.key === 'k' || e.key === 'ArrowUp') {
        e.preventDefault()
        setSelected(rows[Math.max(0, i - 1)]?.slug ?? null)
      } else if (e.key === 'f') setFilter((f) => filters[(filters.indexOf(f) + 1) % filters.length])
      else if (e.key === 'n') {
        e.preventDefault()
        setCreating(true)
      } else if (e.key === '/') {
        e.preventDefault()
        searchRef.current?.focus()
      } else if (e.key === 'a') {
        e.preventDefault()
        goalRef.current?.focus()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [rows, current, creating])

  async function create(input: NewProject) {
    const p = await api.createProject(input)
    setFilter('all')
    setQuery('')
    await refresh()
    setSelected(p.slug)
    setCreating(false)
  }

  const active = projects.filter((p) => p.stage === 'active').length
  const hours = projects.reduce((s, p) => s + p.hoursThisWeek, 0).toFixed(1)

  return (
    <div className="flex h-full flex-col">
      <header className="flex items-center gap-4 border-b border-line px-3 py-1">
        <span className="font-bold text-accent">tracker</span>
        <span className="text-dim">
          <b className="text-fg">{projects.length}</b> projects
        </span>
        <span className="text-dim">
          <b className="text-ok">{active}</b> active
        </span>
        <span className="text-dim">
          <b className="text-warn">{projects.filter(attention).length}</b> need attention
        </span>
        <span className="text-dim">
          <b className="text-cyan">{hours}</b>h this week
        </span>
        <button onClick={() => setCreating(true)} className={`${btn} ml-auto`}>
          n new project
        </button>
      </header>

      {error && (
        <p role="alert" className="border-b border-line px-3 py-1 text-bad">
          couldn’t load projects: {error}. is the backend running?
        </p>
      )}

      <main className="grid min-h-0 flex-1 grid-rows-[auto_1fr] md:grid-cols-[minmax(28ch,38ch)_1fr] md:grid-rows-1">
        <ProjectList
          rows={rows}
          selected={current?.slug ?? null}
          onSelect={setSelected}
          query={query}
          onQuery={setQuery}
          filter={filter}
          searchRef={searchRef}
        />
        <section className="min-h-0 min-w-0">
          {current ? (
            <ProjectDetail slug={current.slug} goalRef={goalRef} />
          ) : (
            <p className="p-3 text-dim">nothing selected. press n to create a project.</p>
          )}
        </section>
      </main>

      <footer className="flex gap-4 border-t border-line px-3 py-1 text-dim">
        <Key k="j/k">move</Key>
        <Key k="/">search</Key>
        <Key k="f">filter</Key>
        <Key k="a">add goal</Key>
        <Key k="n">new</Key>
        <Key k="esc">leave input</Key>
        {isMock && <span className="ml-auto text-warn">mock data</span>}
      </footer>

      {creating && <NewProjectModal onCreate={create} onClose={() => setCreating(false)} />}
    </div>
  )
}
