import type { RefObject } from 'react'
import type { Project } from './types'
import { Chip, edge, gitInfo, input, stageInfo, text } from './ui'

export default function ProjectList({
  rows,
  selected,
  onSelect,
  query,
  onQuery,
  filter,
  searchRef,
}: {
  rows: Project[]
  selected: string | null
  onSelect: (slug: string) => void
  query: string
  onQuery: (q: string) => void
  filter: string
  searchRef: RefObject<HTMLInputElement | null>
}) {
  return (
    <nav className="flex max-h-48 min-h-0 flex-col border-line md:max-h-none md:border-r">
      <div className="flex gap-2 border-b border-line px-2 py-0.5">
        <span className="text-dim">/</span>
        <input
          ref={searchRef}
          value={query}
          onChange={(e) => onQuery(e.target.value)}
          placeholder="search"
          aria-label="Search projects"
          className={input}
        />
        <span className="shrink-0 font-bold text-cyan">{filter === 'attention' ? 'needs attention' : filter}</span>
      </div>

      <ul className="min-h-0 flex-1 overflow-auto">
        {rows.map((p) => {
          const st = stageInfo[p.stage]
          const g = gitInfo[p.git.state]
          const on = p.slug === selected
          return (
            <li key={p.slug}>
              <button
                onClick={() => onSelect(p.slug)}
                aria-current={on}
                className={`flex w-full items-center gap-2 border-l-4 px-2 py-px text-left ${edge[st.tone]} ${
                  on ? 'bg-panel font-bold' : 'hover:bg-panel'
                }`}
              >
                <span className="min-w-0 flex-1 truncate">{p.title}</span>
                {p.git.state === 'clean' ? <span className="text-ok">✓</span> : <Chip tone={g.tone}>{g.label}</Chip>}
                <span className={`w-9 text-right tabular-nums ${p.hoursThisWeek > 0 ? 'text-cyan' : 'text-dim'}`}>
                  {p.hoursThisWeek.toFixed(1)}h
                </span>
              </button>
            </li>
          )
        })}
        {rows.length === 0 && <li className="px-2 py-2 text-dim">no projects match</li>}
      </ul>

      <div className="flex flex-wrap gap-x-3 border-t border-line px-2 py-1">
        {Object.entries(stageInfo).map(([k, v]) => (
          <span key={k} className={text[v.tone]}>
            ▌{k}
          </span>
        ))}
      </div>
    </nav>
  )
}
